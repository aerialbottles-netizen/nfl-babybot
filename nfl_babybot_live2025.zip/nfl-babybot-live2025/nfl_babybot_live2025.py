#!/usr/bin/env python3
# nfl_babybot_live2025.py — live rosters & schedule (2025) via nflverse/nflreadpy
# Features: game win% & implied points, anytime TD picks
# Requires: pandas, nflreadpy
import argparse, math, sys, datetime as dt
from typing import Optional, Dict, List
import pandas as pd

try:
    from nflreadpy import load_schedules, load_depth_charts
    LIVE_OK = True
except Exception:
    LIVE_OK = False

TEAM_MAP = {
    "ARI":"ARI","ATL":"ATL","BAL":"BAL","BUF":"BUF","CAR":"CAR","CHI":"CHI","CIN":"CIN","CLE":"CLE",
    "DAL":"DAL","DEN":"DEN","DET":"DET","GB":"GB","HOU":"HOU","IND":"IND","JAX":"JAX","KC":"KC",
    "LA":"LA","LAR":"LA","RAMS":"LA","LAC":"LAC","CHARGERS":"LAC","LV":"LV","RAIDERS":"LV",
    "MIA":"MIA","MIN":"MIN","NE":"NE","NO":"NO","NYG":"NYG","NYJ":"NYJ","PHI":"PHI","PIT":"PIT",
    "SEA":"SEA","SF":"SF","49ERS":"SF","TB":"TB","TEN":"TEN","WAS":"WAS","COMMANDERS":"WAS"
}
def T(x:str)->str:
    x=(x or "").strip().upper()
    return TEAM_MAP.get(x, x)

HOME_ELO = 48.0
def elo_prob(home_elo=1500.0, away_elo=1500.0):
    diff = (home_elo + HOME_ELO) - away_elo
    return 1.0/(1.0 + 10**(-(diff/400.0)))

def am_to_prob(ml: Optional[float]) -> Optional[float]:
    if ml is None: return None
    return (-ml)/((-ml)+100.0) if ml < 0 else 100.0/(ml+100.0)

def blend(p_elo, p_mkt):
    return 0.6*p_mkt + 0.4*p_elo if p_mkt is not None else p_elo

def implied_points(p_home: float, total: Optional[float]):
    if total is None:
        margin = (p_home-0.5)*12.0
        home = max(23 + margin/2, 7.0)
        away = max(23 - margin/2, 7.0)
    else:
        s = 13.0
        margin = (p_home-0.5)*s*2
        home = max((total + margin)/2, 7.0)
        away = max(total - home, 7.0)
    return home, away

DEF_DEFAULT = dict(def_rush=0.8, def_pass=1.4, rz=0.58)
def parse_defs(s: Optional[str]) -> Dict[str,dict]:
    out={}
    if not s: return out
    for part in s.split(";"):
        part=part.strip()
        if not part or ":" not in part: continue
        t,rest = part.split(":",1); t=T(t)
        d = dict(DEF_DEFAULT)
        for kv in rest.split(","):
            kv=kv.strip()
            if "=" in kv:
                k,v = kv.split("=",1)
                try: d[k.strip()] = float(v.strip())
                except: pass
        out[t]=d
    return out

def get_def(dmap, team):
    d = dmap.get(team, {})
    return {k: d.get(k, DEF_DEFAULT[k]) for k in DEF_DEFAULT}

def apply_def_pts(home_pts, away_pts, home, away, dmap):
    h = get_def(dmap, home); a = get_def(dmap, away)
    def nudge(v, base): return max(min((v-base)*0.9, 1.0), -1.0)
    away_pts += nudge(h["def_rush"]+h["def_pass"], DEF_DEFAULT["def_rush"]+DEF_DEFAULT["def_pass"]) * 0.8
    home_pts += nudge(a["def_rush"]+a["def_pass"], DEF_DEFAULT["def_rush"]+DEF_DEFAULT["def_pass"]) * 0.8
    away_pts += 0.35*nudge(h["def_rush"], DEF_DEFAULT["def_rush"])
    home_pts += 0.35*nudge(a["def_rush"], DEF_DEFAULT["def_rush"])
    away_pts += 0.35*nudge(h["def_pass"], DEF_DEFAULT["def_pass"])
    home_pts += 0.35*nudge(a["def_pass"], DEF_DEFAULT["def_pass"])
    away_pts += 0.45*(h["rz"]-DEF_DEFAULT["rz"])
    home_pts += 0.45*(a["rz"]-DEF_DEFAULT["rz"])
    return max(home_pts,7.0), max(away_pts,7.0)

def weather_total(total, wind, temp, precip):
    if total is None: return None
    adj=0.0; w=wind or 0.0; p=(precip or "none").lower(); t=temp if temp is not None else 60.0
    if w>=15: adj-=1.0
    if w>=20: adj-=1.0
    if p=="rain": adj-=0.8
    if p=="snow": adj-=1.3
    if t<=25: adj-=0.6
    return max(total+adj, 30.0)

def weather_pos(p, pos, wind, temp, precip):
    w=wind or 0.0; pr=(precip or "none").lower(); t=temp if temp is not None else 60.0
    f=1.0
    if w>=15 or pr in ("rain","snow"):
        if pos in ("WR","TE"): f*=0.90
        if pos=="RB": f*=1.08
    if t<=25 and pos in ("WR","TE"):
        f*=0.96
    return max(min(p*f, 0.99), 0.01)

def load_sched_2025() -> pd.DataFrame:
    if not LIVE_OK: raise RuntimeError("nflreadpy not installed")
    df = load_schedules(seasons=[2025], file_type="csv")
    df["home_team"] = df["home_team"].str.upper().map(TEAM_MAP).fillna(df["home_team"].str.upper())
    df["away_team"] = df["away_team"].str.upper().map(TEAM_MAP).fillna(df["away_team"].str.upper())
    return df

def load_depth_2025() -> pd.DataFrame:
    if not LIVE_OK: raise RuntimeError("nflreadpy not installed")
    dc = load_depth_charts(seasons=[2025], file_type="csv")
    dc = dc[dc["pos"].isin(["RB","WR","TE"])]
    return dc

DEPTH_WEIGHTS = {"RB":[0.60,0.28,0.10,0.02], "WR":[0.28,0.22,0.16,0.10,0.06,0.03], "TE":[0.20,0.13,0.07]}
def depth_share(pos: str, slot: int) -> float:
    arr = DEPTH_WEIGHTS.get(pos, [0.5,0.3,0.15,0.05])
    return arr[slot] if slot < len(arr) else max(arr[-1]*0.6**(slot-len(arr)+1), 0.01)

def softmax(xs):
    m=max(xs); ex=[math.exp(x-m) for x in xs]; s=sum(ex)
    return [e/s for e in ex] if s>0 else [1/len(xs)]*len(xs)

def roster_from_depth(dc: pd.DataFrame, team: str, week: Optional[int]) -> List[dict]:
    tdc = dc[dc["team"].str.upper().map(TEAM_MAP).fillna(dc["team"].str.upper()) == team]
    if week is not None and "week" in tdc.columns:
        tdc = tdc[tdc["week"] == week] or tdc
    if tdc.empty:
        return [
            {"player": f"{team} RB1", "pos":"RB", "touches":0.58, "rz_rush":0.35, "inside5":0.25},
            {"player": f"{team} WR1", "pos":"WR", "targets":0.28, "rz_tgt":0.30, "endzone":0.20},
            {"player": f"{team} WR2", "pos":"WR", "targets":0.22, "rz_tgt":0.22, "endzone":0.14},
            {"player": f"{team} TE1", "pos":"TE", "targets":0.18, "rz_tgt":0.22, "endzone":0.12},
        ]
    name_col = "player_name" if "player_name" in tdc.columns else "gsis_name" if "gsis_name" in tdc.columns else "player"
    slot_col = "depth_chart_order" if "depth_chart_order" in tdc.columns else "depth_team_pos" if "depth_team_pos" in tdc.columns else None
    out = []
    for pos in ["RB","WR","TE"]:
        grp = tdc[tdc["pos"]==pos].copy()
        if grp.empty: continue
        if slot_col and slot_col in grp.columns:
            grp = grp.sort_values(slot_col)
        else:
            grp = grp.sort_values(name_col)
        for i, (_,r) in enumerate(grp.iterrows()):
            if pos=="RB":
                out.append({"player": str(r.get(name_col,"")), "pos":"RB",
                            "touches": depth_share("RB", i), "rz_rush":0.40*(0.8**i), "inside5":0.28*(0.75**i)})
            elif pos=="WR":
                out.append({"player": str(r.get(name_col,"")), "pos":"WR",
                            "targets": depth_share("WR", i), "rz_tgt":0.28*(0.85**i), "endzone":0.18*(0.85**i)})
            elif pos=="TE":
                out.append({"player": str(r.get(name_col,"")), "pos":"TE",
                            "targets": depth_share("TE", i), "rz_tgt":0.22*(0.85**i), "endzone":0.12*(0.85**i)})
    return out

def predict_game(away, home, ml_home=None, ml_away=None, total=None, defense=None, wind=None, temp=None, precip=None):
    away, home = T(away), T(home)
    p_elo = elo_prob()
    if ml_home is not None and ml_away is not None:
        ph = am_to_prob(ml_home); pa = am_to_prob(ml_away)
        p_mkt = ph/(ph+pa) if (ph is not None and pa is not None and ph+pa>0) else None
    else:
        p_mkt = None
    p_home = blend(p_elo, p_mkt)
    home_pts, away_pts = implied_points(p_home, total)
    defs = parse_defs(defense)
    home_pts, away_pts = apply_def_pts(home_pts, away_pts, home, away, defs)
    if total is not None:
        adj_total = weather_total(home_pts+away_pts, wind, temp, precip)
        margin = home_pts - away_pts
        home_pts = max((adj_total + margin)/2, 7.0)
        away_pts = max(adj_total - home_pts, 7.0)
    return dict(home=home, away=away, p_home=p_home, p_away=1-p_home, home_pts=home_pts, away_pts=away_pts)

def score_row(row, team_imp, opp_def):
    pos=row["pos"]; touches=row.get("touches",0.0); targets=row.get("targets",0.0)
    rz_rush=row.get("rz_rush",0.0); rz_tgt=row.get("rz_tgt",0.0); endzone=row.get("endzone",0.0); inside5=row.get("inside5",0.0)
    w = {"touches": 2.2 if pos=="RB" else 1.3, "targets": 1.55 if pos in ("WR","TE") else 0.6,
         "rz_rush": 1.0, "rz_tgt": 1.0, "endzone": 1.2 if pos in ("WR","TE") else 0.55, "inside5": 1.7,
         "team_imp": 0.065, "rush_allow": 1.10 if pos=="RB" else 0.25,
         "pass_allow": 1.10 if pos in ("WR","TE") else 0.25, "rz_allow": 0.9}
    score = (w["touches"]*touches + w["targets"]*targets + w["rz_rush"]*rz_rush + w["rz_tgt"]*rz_tgt +
             w["endzone"]*endzone + w["inside5"]*inside5 + w["team_imp"]*team_imp +
             w["rush_allow"]*opp_def["def_rush"] + w["pass_allow"]*opp_def["def_pass"] + w["rz_allow"]*(opp_def["rz"]-0.58))
    return score

def softmax_rank_anytime(roster, team_imp, opp_def, wind, temp, precip):
    scores=[score_row(r, team_imp, opp_def) for r in roster]
    weights=softmax(scores)
    team_td_expect = max(team_imp/7.0, 0.8)
    out=[]
    for r, w in zip(roster, weights):
        lam = team_td_expect * w
        p_any = 1 - math.exp(-lam)
        p_any = weather_pos(p_any, r["pos"], wind, temp, precip)
        out.append({"player": r["player"], "team": r.get("team",""), "pos": r["pos"], "prob": p_any})
    return out

def td_picks(away, home, top=8, defense=None, wind=None, temp=None, precip=None, ml_home=None, ml_away=None, total=None, week: Optional[int]=None):
    g = predict_game(away, home, ml_home, ml_away, total, defense, wind, temp, precip)
    home, away = T(home), T(away)
    defs = parse_defs(defense)
    home_def = get_def(defs, home); away_def = get_def(defs, away)
    if LIVE_OK:
        dc = load_depth_2025()
        home_roster = roster_from_depth(dc, home, week); [r.update({"team":home}) for r in home_roster]
        away_roster = roster_from_depth(dc, away, week); [r.update({"team":away}) for r in away_roster]
    else:
        home_roster = roster_from_depth(pd.DataFrame(), home, week); [r.update({"team":home}) for r in home_roster]
        away_roster = roster_from_depth(pd.DataFrame(), away, week); [r.update({"team":away}) for r in away_roster]
    home_imp, away_imp = g["home_pts"], g["away_pts"]
    out = softmax_rank_anytime(home_roster, home_imp, away_def, wind, temp, precip) +           softmax_rank_anytime(away_roster, away_imp, home_def, wind, temp, precip)
    out.sort(key=lambda x: x["prob"], reverse=True)
    return out[:max(1, top)], g

def main():
    ap = argparse.ArgumentParser(description="BabyBot LIVE 2025 — real schedule & depth charts via nflverse")
    sub = ap.add_subparsers(dest="cmd")
    def add_common(p):
        p.add_argument("away", type=str)
        p.add_argument("home", type=str)
        p.add_argument("--ml_home", type=float, default=None)
        p.add_argument("--ml_away", type=float, default=None)
        p.add_argument("--total", type=float, default=None)
        p.add_argument("--defense", type=str, default=None)
        p.add_argument("--wind", type=float, default=None)
        p.add_argument("--temp", type=float, default=None)
        p.add_argument("--precip", type=str, default=None)
        p.add_argument("--week", type=int, default=None, help="Force specific 2025 week if teams play multiple times")
    p1 = sub.add_parser("game", help="Win% & implied points"); add_common(p1)
    p2 = sub.add_parser("tds", help="Anytime TD picks"); add_common(p2); p2.add_argument("--top", type=int, default=8)

    args = ap.parse_args()
    away, home = T(args.away), T(args.home)

    if args.cmd == "game":
        g = predict_game(away, home, args.ml_home, args.ml_away, args.total, args.defense, args.wind, args.temp, args.precip)
        print(f"{away} @ {home}")
        print(f"Home win: {g['p_home']*100:.1f}% | Away win: {g['p_away']*100:.1f}%")
        print(f"Implied points: {home} {g['home_pts']:.1f}  |  {away} {g['away_pts']:.1f}  (Total {(g['home_pts']+g['away_pts']):.1f})")
        return

    if args.cmd == "tds":
        wk = args.week
        if LIVE_OK:
            try:
                sched = load_sched_2025()
                if wk is None:
                    tmp = sched[(sched["home_team"]==home)&(sched["away_team"]==away)]
                    if tmp.empty: tmp = sched[(sched["home_team"]==away)&(sched["away_team"]==home)]
                    if not tmp.empty: wk = int(tmp.sort_values("week").iloc[0]["week"])
            except Exception:
                wk = None
        picks, g = td_picks(away, home, args.top, args.defense, args.wind, args.temp, args.precip, args.ml_home, args.ml_away, args.total, week=wk)
        print(f"Anytime TD picks — {away} @ {home} (Week {wk if wk else '?'} | top {args.top})")
        for r in picks:
            print(f"• {r['player']} ({r['team']} {r['pos']}) — {r['prob']*100:.1f}%")
        return

    ap.print_help()

if __name__ == "__main__":
    main()

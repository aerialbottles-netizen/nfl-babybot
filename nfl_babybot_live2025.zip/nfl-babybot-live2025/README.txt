NFL BabyBot LIVE 2025
Auto-pulls 2025 schedules and depth charts (RB/WR/TE) from nflverse via nflreadpy.

Install:
  python3 -m pip install --upgrade pip
  python3 -m pip install pandas nflreadpy

Run examples:
  # Rams @ 49ers — anytime TDs (auto 2025 rosters)
  python3 nfl_babybot_live2025.py tds LA SF --top 8

  # Eagles @ Cowboys — win% and implied points
  python3 nfl_babybot_live2025.py game PHI DAL --total 47.5

  # Add defense & weather knobs
  python3 nfl_babybot_live2025.py tds LA SF --defense "LA:def_rush=1.05,def_pass=1.10,rz=0.60; SF:def_rush=0.85,def_pass=0.95,rz=0.52" --wind 8 --temp 60 --precip none --top 8

Notes:
- If you're offline or nflreadpy isn't installed, the bot falls back to generic rosters.
- Force a specific 2025 week with --week N.
